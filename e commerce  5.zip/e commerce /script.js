
document.addEventListener('DOMContentLoaded', () => {
    const progressBars = document.querySelectorAll('.progress');
  
    // Example progress values for demonstration (can be fetched dynamically)
    const progressValues = [20, 40, 60, 80]; // These represent percentages (e.g., 20%, 40%, etc.)
  
    progressBars.forEach((bar, index) => {
      // Safely check if a corresponding progress value exists
      if (progressValues[index] !== undefined) {
        // Simulate a delay for smooth animation
        setTimeout(() => {
          bar.style.width = `${progressValues[index]}%`; // Set the progress width
        }, 500 * (index + 1)); // Add delay based on index for a staggered effect
      }
    });

  });
  